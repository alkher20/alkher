<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Outputs an array in a user-readable JSON format
 *
 * @param array $array
 */

if (!function_exists('get_time')) {
    function get_time($id=6,$date)
    {
        $CI =& get_instance();
        $check  = $CI->attendance_model->check_date_is_leave_by_id($id, $date);

        if(empty($check)) {
            
            $attendance = $CI->attendance_model->get_attendance_by_user($id, $date);
            if(empty($attendance)) {
                return "N/A";
            }    
            foreach($attendance as $new){
                $times [] = $new->diff;
                    
            }
            return sum_the_time($times);
        }else{
            return $check->leave_type;
        }        
    }
}

if (!function_exists('sum_the_time')) {
    function sum_the_time($times)
    {
        $seconds = 0;
        foreach ($times as $time)
        {
            if(empty($time)) {
                $time="00:00:00";
            }
            
            list($hour,$minute,$second) = explode(':', @$time);
            $seconds += $hour*3600;
            $seconds += $minute*60;
            $seconds += $second;
        }
        $hours = floor($seconds/3600);
        $seconds -= $hours*3600;
        $minutes  = floor($seconds/60);
        $seconds -= $minutes*60;
        return sprintf('%02d h %02d m %02d s', $hours, $minutes, $seconds); 
    }
}

if (!function_exists('get_holidays')) 
{
    function get_holidays($m)
    {
        $CI = &get_instance();
        $holidays = $CI->holiday_model->get_holidays_by_month($m);
        $default_days = $CI->holiday_model->get_default_holidays();
        $dates=array();
        foreach($default_days as $new){
        
            $dates = array_merge(
                $dates, $CI->db->query(
                    "select row+1  as DayOfMonth from   
        ( SELECT @row := @row + 1 as row FROM
          (select 0 union all select 1 union all select 3 union all select 4 union all select 5 union all select 6) t1,
          (select 0 union all select 1 union all select 3 union all select 4 union all select 5 union all select 6) t2,
          (SELECT @row:=-1) t3 limit 31 ) b where
             DATE_ADD('".date('Y-'.$m.'-01')."', INTERVAL ROW DAY) between '".date('Y-'.$m.'-01')."' and '".date('Y-'.$m.'-t')."' and DAYOFWEEK(DATE_ADD('".date('Y-'.$m.'-01')."', INTERVAL ROW DAY))=".$new->id.";" /* $new->id is for number of days  */
                )->result_array()
            );
        }
        $dates = array_merge($dates, $holidays);
                
        $dates[] = usort($dates, 'sortByOrder');
        return $dates;
    }

}


if (!function_exists('sortByOrder')) 
{
    function sortByOrder($a, $b)
    {
        if($a['DayOfMonth']>31) 
        {
            return ;
        }
        else
        {
            return $a['DayOfMonth'] - $b['DayOfMonth'];
        }
    }
}
