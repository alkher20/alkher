<?php if (! defined('BASEPATH')) { exit('No direct script access allowed');
}

class case_stage extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();        
        $this->load->model("case_stage_model");


        $this->add_external_css(base_url('assets/plugins/datatables/dataTables.bootstrap.css'));
        $this->add_external_css(base_url('assets/plugins/jquery.datetimepicker/jquery.datetimepicker.css'));
        $this->add_external_css(base_url('assets/plugins/chosen/chosen.css'));

        $this->add_external_js(base_url('assets/plugins/datatables/jquery.dataTables.js'));
        $this->add_external_js(base_url('assets/plugins/datatables/dataTables.bootstrap.js'));
        $this->add_external_js(base_url('assets/plugins/jquery.datetimepicker/jquery.datetimepicker.js'));

        $this->add_external_js(base_url('assets/plugins/chosen/chosen.jquery.min.js'));
        $this->add_external_js(base_url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'));
        $this->add_external_js(base_url('assets/js/bootstrap-datepicker.js'));
        $this->add_external_js(base_url('assets/js/case_stage/script.js'));

    }
    
    
    function index()
    {
        $data = $this->includes;
        $data['stages'] = $this->case_stage_model->get_all();
        $data['page_title'] = lang('case') . " " .lang('stages');
        $data['body'] = 'case_stages/list';
        $this->load->view('template/main', $data);    
    }    
    
    function add()
    {
        $data = $this->includes;
        if ($this->input->server('REQUEST_METHOD') === 'POST') {    
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'lang:name', 'required');
            $this->form_validation->set_message('required', lang('custom_required'));
             
            if ($this->form_validation->run()==true) {
                $save['name'] = $this->input->post('name');
                
                $this->case_stage_model->save($save);
                $this->session->set_flashdata('message', lang('case_stage_created'));
                redirect('admin/case_stage');
                
            }
        }        
        
        
        $data['page_title'] = lang('add') . lang('case') . lang('stage');
        $data['body'] = 'case_stages/add';
        
        $this->load->view('template/main', $data);    
    }    
    
    
    function edit($id=false)
    {
     
        $data = $this->includes;   
        $data['stage'] = $this->case_stage_model->get_case_stage_by_id($id);
        $data['id'] =$id;
    
        if ($this->input->server('REQUEST_METHOD') === 'POST') {    
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'lang:name', 'required');
            $this->form_validation->set_message('required', lang('custom_required'));
             
            if ($this->form_validation->run()==true) {
                $save['name'] = $this->input->post('name');
                $this->case_stage_model->update($save, $id);
                $this->session->set_flashdata('message', lang('case_stage_updated'));
                redirect('admin/case_stage');
                
            }
        }        
    

        $data['page_title'] = lang('edit') . lang('case') . lang('stage');
        $data['body'] = 'case_stages/edit';
        $this->load->view('template/main', $data);    

    }    
    
    function delete($id=false)
    {
        $data = $this->includes;
        if($id) {
            $this->case_stage_model->delete($id);
            $this->session->set_flashdata('message', lang('case_stage_deleted'));
            redirect('admin/case_stage');
        }
    }    
        
    
}
