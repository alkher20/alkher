<?php if (! defined('BASEPATH')) { exit('No direct script access allowed'); }

class reports extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("reports_model");

        $this->add_external_css(base_url('assets/plugins/datatables/dataTables.bootstrap.css'));
        $this->add_external_css(base_url('assets/plugins/jquery.datetimepicker/jquery.datetimepicker.css'));
        $this->add_external_css(base_url('assets/plugins/chosen/chosen.css'));

        $this->add_external_js(base_url('assets/plugins/datatables/jquery.dataTables.js'));
        $this->add_external_js(base_url('assets/plugins/datatables/dataTables.bootstrap.js'));
        $this->add_external_js(base_url('assets/plugins/jquery.datetimepicker/jquery.datetimepicker.js'));

        $this->add_external_js(base_url('assets/plugins/chosen/chosen.jquery.min.js'));
        $this->add_external_js(base_url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'));
        $this->add_external_js(base_url('assets/js/bootstrap-datepicker.js'));
        $this->add_external_js(base_url('assets/js/redactor.min.js'));

        $this->add_external_js(base_url('assets/plugins/morris/raphael-min.js')); 
        $this->add_external_js(base_url('assets/plugins/morris/morris.min.js')); 
        $this->add_external_js(base_url('assets/js/reports/script.js')); 
        
    }
    
    
    function index()
    {
        $data = $this->includes;
        $data['months'] = $this->reports_model->get_earning_by_month();
        $data['weeks'] = $this->reports_model->get_earning_by_week();
        $data['years'] = $this->reports_model->get_earning_by_year();
        $data['clients'] = $this->reports_model->get_earning_by_client();
        $data['page_title'] = lang('reports');
        $data['body'] = 'reports/reports';
        $this->load->view('template/main', $data);    

    }    
    
        
        
    
}
