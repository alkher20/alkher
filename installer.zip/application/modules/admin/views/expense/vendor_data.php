<div >Name: <?php echo ($vendor_data->name) ? $vendor_data->name : "-"; ?></div>
<div>Address: <?php echo ($vendor_data->address) ? $vendor_data->address : "-";?></div>
<div>Gender: <?php echo ($vendor_data->gender) ? $vendor_data->gender : "-";?></div>
<div>Contact: <?php echo ($vendor_data->contact) ? $vendor_data->contact : "-" ;?></div>
<div>Email: <?php echo ($vendor_data->email) ? $vendor_data->email : "-" ;?></div>
