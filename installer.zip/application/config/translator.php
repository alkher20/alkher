<?php

/* Where are the language files */
$config['translator_langDir'] = APPPATH . 'language';

/* c$Where are the language files */
$config['translator_masterLang'] = 'english';

?>
